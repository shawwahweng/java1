/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part1;

import java.util.Scanner;


public class Q006 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
         int asterisks;

        for(asterisks=1; asterisks<=4; asterisks++){
            System.out.println("* * * * * * * * ");
            System.out.println(" * * * * * * * * ");
        }

    }
}
