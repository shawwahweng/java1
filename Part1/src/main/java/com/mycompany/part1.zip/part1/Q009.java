/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part1;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class Q009 {
     public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        int num1,num2,num3,num4,num5;
        System.out.print("Enter five number:");
        num1=input.nextInt();
        num2=input.nextInt();
        num3=input.nextInt();
        num4=input.nextInt();
        num5=input.nextInt();
        System.out.printf("%d   %d   %d   %d   %d   ",num1,num2,num3,num4,num5);
        
        


    }

}